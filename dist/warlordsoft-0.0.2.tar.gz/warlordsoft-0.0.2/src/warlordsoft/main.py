import webbrowser

url = "https://warlordsoftwares.in/warlord_soft/dashboard/"
webbrowser.open(url)
